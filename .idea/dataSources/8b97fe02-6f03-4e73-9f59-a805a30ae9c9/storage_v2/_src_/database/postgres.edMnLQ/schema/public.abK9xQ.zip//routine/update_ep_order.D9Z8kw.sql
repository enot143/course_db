create function update_ep_order(integer, integer) returns void
    language sql
as
$$
UPDATE EP_INSTANCE
        set Number=$2 where Episode_ID=$1;
$$;

alter function update_ep_order(integer, integer) owner to s263905;

