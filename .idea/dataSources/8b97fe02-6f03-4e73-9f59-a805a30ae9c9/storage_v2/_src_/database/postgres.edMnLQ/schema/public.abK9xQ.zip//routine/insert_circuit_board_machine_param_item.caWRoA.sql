create function insert_circuit_board_machine_param_item(machines_count integer, cbmodels_count integer) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    random_speed integer := 0;
    circuit_board_model_row circuit_board_model%ROWTYPE;
    machine_id integer := 0;
begin
    for i in 1..cbmodels_count loop
        machine_id = (random() * (machines_count - 1) + 1)::integer;
        select id, version into circuit_board_model_row from circuit_board_model order by id limit 1 offset i;
        random_speed := (random() * ( 100 - 10) + 10)::real;
        insert into circuit_board_machine_param_item values (machine_id, circuit_board_model_row.id, circuit_board_model_row.version, random_speed);
    end loop;
END
$$;

alter function insert_circuit_board_machine_param_item(integer, integer) owner to s264429;

