create function get_land_id_by_citizen_id(integer) returns integer
    language plpgsql
as
$$
declare
    result_land integer;
begin
    select city.land_id from citizen
                                 join city on citizen.city_id = city.id
    where citizen.id = $1
    into result_land;

    return result_land;
end;
$$;

alter function get_land_id_by_citizen_id(integer) owner to s264484;

