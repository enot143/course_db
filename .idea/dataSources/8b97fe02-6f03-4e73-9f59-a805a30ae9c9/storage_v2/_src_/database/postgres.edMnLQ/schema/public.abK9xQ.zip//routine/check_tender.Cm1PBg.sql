create function check_tender() returns trigger
    language plpgsql
as
$$
begin
        if ((select Статус_тендера from Тендер where id = NEW.id) = false) then
            raise exception 'Данный тендер не выигран';
        end if;
        return null;
        end;
$$;

alter function check_tender() owner to s263232;

