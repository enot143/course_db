create function get_dragon_of_citizen(integer) returns integer
    language plpgsql
as
$$
begin
    return (select dragon_id from citizen where  citizen.id = $1);
end;
$$;

alter function get_dragon_of_citizen(integer) owner to s264484;

