create function add_tea_to_products() returns trigger
    language plpgsql
as
$$
declare
    _id integer := 0;
begin
    insert into product(name) values ('Tea') returning id into _id;
    NEW.super_id := _id;
    return new;
end;
$$;

alter function add_tea_to_products() owner to s264429;

