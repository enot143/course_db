create function updepinst() returns trigger
    language plpgsql
as
$$
BEGIN
INSERT INTO ep_instance(ft_id, episode_id, number )
 VALUES (0 ,new.Episode_ID, 0);
RETURN NEW;
    end;
$$;

alter function updepinst() owner to s263905;

