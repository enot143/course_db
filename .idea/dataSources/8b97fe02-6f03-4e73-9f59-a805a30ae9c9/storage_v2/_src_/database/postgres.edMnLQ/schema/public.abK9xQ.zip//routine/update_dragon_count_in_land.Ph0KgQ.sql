create function update_dragon_count_in_land() returns trigger
    language plpgsql
as
$$
declare
    land_dragon_count integer;
    index             integer;
begin
    ---считаем количество драконов по странам
    for index in
        select id from land
        loop
            select count(*) into land_dragon_count from dragon where index = land_id;
            update land set dragon_count = land_dragon_count where land.id = index;
        end loop;
    -- при вставке дракона, обновляется таблица combat_unit
    if (tg_op = 'INSERT') then
        insert into combat_unit (land_id, soldier_id, combat_dragon_id) values
        (new.land_id, null, new.id);
    end if;
    return new;
end;
$$;

alter function update_dragon_count_in_land() owner to s264484;

