create function update_curr_prof_id() returns trigger
    language plpgsql
as
$$
declare
    cur_prof_id integer;
begin
    select current_profession_id into cur_prof_id from citizen where id = old.citizen_id;
    if (old.profession_id = cur_prof_id) then
        update citizen set current_profession_id = null where id = old.citizen_id;
    end if;
end;
$$;

alter function update_curr_prof_id() owner to s264484;

