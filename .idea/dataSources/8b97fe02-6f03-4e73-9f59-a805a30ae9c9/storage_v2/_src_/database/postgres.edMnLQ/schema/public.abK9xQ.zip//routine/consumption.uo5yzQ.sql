create function consumption() returns trigger
    language plpgsql
as
$$
DECLARE
    emp integer;
    before integer;
    after integer;
BEGIN
    FOR emp IN SELECT id FROM isbs LIMIT (SELECT count(*) FROM isbs WHERE is_builded = true)
        LOOP
            IF ((SELECT oxygen FROM isbs WHERE id = emp) < 0 OR
                (SELECT food FROM isbs WHERE id = emp) < 0) THEN
                UPDATE volunteer SET isbs_id = null, environment_id = null, on_work = false WHERE isbs_id = emp;
                RAISE NOTICE 'Купол номер % непригоден к эксплуатации', (SELECT id FROM isbs WHERE id=emp);
            ELSEIF ((SELECT money FROM total_money) < 0) THEN
                UPDATE volunteer SET isbs_id = null, environment_id = null, on_work = false WHERE isbs_id = emp;
                RAISE NOTICE 'МЫ БАНКРОТЫ!';
            END IF;
        END LOOP;
    FOR emp IN SELECT id FROM environment LIMIT (SELECT count(*) FROM environment)
        LOOP
            UPDATE environment SET
            consumption_oxygen = (SELECT sum(n.consumption_oxygen) FROM nature n
            INNER JOIN environment e on n.environment_id = e.id
            WHERE environment_id = emp)
            WHERE id = emp;
        END LOOP;
    FOR emp IN SELECT id FROM isbs WHERE is_builded = true LIMIT (SELECT count(*) FROM isbs)
        LOOP
            before = (SELECT oxygen FROM isbs WHERE id = emp);
            UPDATE isbs SET

            food = food - (SELECT sum(need_food) FROM volunteer
            INNER JOIN isbs ON volunteer.isbs_id = isbs.id
            WHERE volunteer.on_work = true AND volunteer.isbs_id = emp),

            oxygen = oxygen - (SELECT sum(need_oxygen) FROM volunteer
            INNER JOIN isbs ON volunteer.isbs_id = isbs.id
            WHERE volunteer.on_work = true AND volunteer.isbs_id = emp)

            WHERE is_builded = true AND id = emp;

            IF ((SELECT count(*) FROM environment WHERE isbs_id = emp) > 0) THEN
            UPDATE isbs SET
            oxygen = oxygen - (SELECT sum(consumption_oxygen) FROM environment
            WHERE environment.isbs_id = emp)
            WHERE id = emp;
            END IF;

            after = (SELECT oxygen FROM isbs WHERE id = emp);

            IF (after > before) THEN
                UPDATE isbs SET auto_oxygen = true WHERE id = emp;
            ELSE
                UPDATE isbs SET auto_oxygen = false WHERE id = emp;
            END IF;
        END LOOP;

    UPDATE total_money SET money = money - (SELECT sum(need_money) FROM volunteer WHERE on_work = true);
    UPDATE transport SET distance = distance - (SELECT speed FROM transport WHERE ready = false) WHERE ready = false;

    RETURN null;
END
$$;

alter function consumption() owner to s263977;

