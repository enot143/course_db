create function insert_legal_entities(count integer, fnames character varying[], mnames character varying[], lnames character varying[], emails character varying[], companies_names character varying[]) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    phone bigint := 0;
    ITin bigint := 0;
begin
    for i in 1..count loop
        phone := (random() * (9999999999 - 9000000000) + 9000000000)::bigint;
        ITin := (random() * (9999999999 - 0) + 0)::bigint;
        insert into customer(type, fname, mname, lname, email, phone, ITin, company_name)
        values ('legal_entity', fnames[i], mnames[i], lnames[i],emails[i], phone, ITin, companies_names[i]);
    end loop;
END
$$;

alter function insert_legal_entities(integer, character varying[], character varying[], character varying[], character varying[], character varying[]) owner to s264429;

