create function stole_resource() returns trigger
    language plpgsql
as
$$
declare
    res_count integer;
begin
    if (tg_op = 'INSERT') then
        if (not is_enough_res(new.injured_city_id, new.thief_city_id, new.resource_type, new.resource_count)) then
            raise exception 'Нечего красть';
        end if;
        return new;
    elsif (tg_op = 'UPDATE') then
        --update запрещен
        raise exception 'Изменение данных запрещено';
    elsif (tg_op = 'DELETE') then
        if (old.thief_city_id is not null and
            not is_enough_res(old.thief_city_id, old.injured_city_id, old.resource_type, old.resource_count)) then
            raise exception 'Недостаточно ресурсов, чтобы вернуть их';
        else
            if (old.resource_type = 'food') then
                select food into res_count from city where city.id = old.injured_city_id;
                update city set food = (res_count + old.resource_count) where id = old.injured_city_id;
            elsif (old.resource_type = 'material') then
                select food into res_count from city where city.id = old.injured_city_id;
                update city set materials = (res_count + old.resource_count) where id = old.injured_city_id;
            elsif (old.resource_type = 'arms') then
                select arms into res_count from city where city.id = old.injured_city_id;
                update city set arms = (res_count + old.resource_count) where id = old.injured_city_id;
            elsif (old.resource_type = 'money') then
                select money into res_count from city where city.id = old.injured_city_id;
                update city set money = (res_count + old.resource_count) where id = old.injured_city_id;
            end if;
        end if;
        return old;
    end if;
end;
$$;

alter function stole_resource() owner to s264484;

