create function check_case_performer() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT COUNT (*) FROM case_performer
        WHERE case_performer.case_id = NEW.case_id) >= 2
    THEN
        RAISE EXCEPTION 'there should be not more then 2 performers';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_case_performer() owner to s288870;

