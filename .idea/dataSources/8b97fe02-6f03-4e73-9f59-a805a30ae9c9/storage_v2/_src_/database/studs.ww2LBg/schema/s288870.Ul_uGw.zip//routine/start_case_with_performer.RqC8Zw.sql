create function start_case_with_performer() returns trigger
    language plpgsql
as
$$
DECLARE
    clientNull boolean;
BEGIN
    clientNull := (SELECT "case".client_id FROM "case" WHERE ("case".case_id = NEW.case_id)) is NOT NULL;
    IF (clientNull AND (SELECT "case".address_id FROM "case" WHERE ("case".case_id = NEW.case_id)) is NOT NULL)
    THEN UPDATE "case"
         SET start_date = now() WHERE "case".case_id = NEW.case_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function start_case_with_performer() owner to s288870;

