create function set_suspect_criminal(suspect_id integer) returns void
    language plpgsql
as
$$
BEGIN
    IF EXISTS(SELECT human_id FROM criminal WHERE criminal.human_id =
                                                  (SELECT suspect.human_id FROM suspect WHERE suspect.suspect_id = set_suspect_criminal.suspect_id))
    THEN
        UPDATE suspect
        SET is_criminal = true WHERE suspect.suspect_id = set_suspect_criminal.suspect_id;
    ELSE
        UPDATE suspect
        SET is_criminal = false WHERE suspect.suspect_id = set_suspect_criminal.suspect_id;
    END IF;
END;
$$;

alter function set_suspect_criminal(integer) owner to s288870;

