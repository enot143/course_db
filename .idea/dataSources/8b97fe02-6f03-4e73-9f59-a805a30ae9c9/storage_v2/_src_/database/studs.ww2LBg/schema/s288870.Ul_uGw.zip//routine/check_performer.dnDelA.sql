create function check_performer() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS(SELECT NEW.human_id FROM criminal WHERE criminal.human_id = NEW.human_id) THEN
        RAISE EXCEPTION 'performer mustn’t be a criminal';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_performer() owner to s288870;

