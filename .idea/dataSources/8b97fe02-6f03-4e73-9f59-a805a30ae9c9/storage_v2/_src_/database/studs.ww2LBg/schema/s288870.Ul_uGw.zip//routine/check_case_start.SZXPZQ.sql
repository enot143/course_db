create function check_case_start() returns trigger
    language plpgsql
as
$$
BEGIN
    IF ((SELECT "case".start_date FROM "case" WHERE "case".case_id = NEW.case_id) is NULL)
    THEN RAISE EXCEPTION 'case is not started yet!';
    END IF;
    IF ((SELECT "case".end_date FROM "case" WHERE "case".case_id = NEW.case_id) is NOT NULL)
    THEN RAISE EXCEPTION 'case has been finished!';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_case_start() owner to s288870;

