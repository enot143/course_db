create function insert_suspect(appearance text, human_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    suspect integer;
BEGIN
    INSERT INTO suspect (appearance, human_id)
    VALUES (insert_suspect.appearance, insert_suspect.human_id) RETURNING suspect_id INTO suspect;
    PERFORM set_suspect_criminal(suspect);
    RETURN suspect;
END;
$$;

alter function insert_suspect(text, integer) owner to s288870;

