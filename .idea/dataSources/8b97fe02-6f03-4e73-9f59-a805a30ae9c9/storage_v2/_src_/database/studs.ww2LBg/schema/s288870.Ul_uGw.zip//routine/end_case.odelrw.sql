create function end_case(case_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    cur_criminal  criminal%rowtype;
BEGIN
    IF ((SELECT "case".start_date FROM "case" WHERE "case".case_id = end_case.case_id) IS NULL) THEN
        RAISE EXCEPTION 'case is not started yet';
    END IF;
    IF ((SELECT "case".end_date FROM "case" WHERE "case".case_id = end_case.case_id) IS NOT NULL) THEN
        RAISE EXCEPTION 'case has already been finished';
    END IF;
    IF ((SELECT COUNT(*) FROM criminal WHERE criminal.case_id = end_case.case_id) < 1 ) THEN
        RAISE EXCEPTION 'in case must be found at least 1 criminal';
    END IF;
    FOR cur_criminal IN (SELECT * FROM criminal WHERE criminal.case_id = end_case.case_id)
        LOOP
            IF (cur_criminal.punishment_id IS NULL) THEN
                RAISE EXCEPTION 'each criminal must have a punishment';
            END IF;
        END LOOP;
    UPDATE "case"
    SET end_date = now() WHERE "case".case_id = end_case.case_id;
    RETURN 1;
END;
$$;

alter function end_case(integer) owner to s288870;

