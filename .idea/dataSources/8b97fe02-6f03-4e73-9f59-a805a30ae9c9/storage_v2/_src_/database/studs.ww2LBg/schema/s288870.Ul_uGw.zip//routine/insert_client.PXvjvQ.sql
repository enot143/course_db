create function insert_client(name text, surname text, age integer, gender boolean, profession text, police boolean, cash integer) returns integer
    language plpgsql
as
$$
DECLARE
    human integer;
BEGIN
    INSERT INTO human (name, surname, age, gender, profession)
    VALUES (insert_client.name, insert_client.surname, insert_client.age, insert_client.gender, insert_client.profession)
    RETURNING human_id INTO human;
    INSERT INTO client (police, cash, human_id)
    VALUES (insert_client.police, insert_client.cash, human);
    RETURN human;
END;
$$;

alter function insert_client(text, text, integer, boolean, text, boolean, integer) owner to s288870;

