create function set_money() returns trigger
    language plpgsql
as
$$
DECLARE
    cur_source source%rowtype;
    sum int;
    counter int;
BEGIN
    sum := 0;
    counter := 0;
    FOR cur_source IN (SELECT * FROM "source" WHERE source.source_id = NEW.source_id)
        LOOP
            IF (cur_source.source_rating IS NOT NULL) THEN
                sum := sum + cur_source.source_rating;
                counter:= counter + 1;
            END IF;
        END LOOP;
    UPDATE client
    SET cash = 1000 * sum / counter WHERE (client.client_id = (SELECT client_id FROM "case" WHERE "case".case_id = NEW.case_id));
    RETURN NEW;
END;
$$;

alter function set_money() owner to s288870;

