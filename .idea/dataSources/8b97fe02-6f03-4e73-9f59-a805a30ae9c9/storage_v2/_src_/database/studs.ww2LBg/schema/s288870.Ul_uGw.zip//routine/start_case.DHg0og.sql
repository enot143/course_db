create function start_case() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW.client_id is NOT NULL
        AND NEW.address_id is NOT NULL
        AND (SELECT COUNT (*) FROM case_performer
             WHERE case_performer.case_id = NEW.case_id) >= 1)
    THEN UPDATE "case"
         SET start_date = now() WHERE "case".case_id = NEW.case_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function start_case() owner to s288870;

