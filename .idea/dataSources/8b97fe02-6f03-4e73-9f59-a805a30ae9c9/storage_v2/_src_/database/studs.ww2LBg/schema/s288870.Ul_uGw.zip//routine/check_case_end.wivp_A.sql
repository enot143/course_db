create function check_case_end() returns trigger
    language plpgsql
as
$$
BEGIN
    IF ((SELECT "case".start_date FROM "case" WHERE "case".case_id = NEW.case_id) is NULL)
    THEN RAISE EXCEPTION 'case is not started yet!';
    END IF;
    IF ((SELECT "case".end_date FROM "case" WHERE "case".case_id = NEW.case_id) is NULL)
    THEN RAISE EXCEPTION 'case has not been finished yet!';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_case_end() owner to s288870;

